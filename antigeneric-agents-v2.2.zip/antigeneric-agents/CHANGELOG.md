# Changelog

All notable changes to this project are documented in this file.
This project uses a simple date-based format.

## 2025-09-07 — AGENTS.md compatibility and spec integration

- Added root spec: [AGENTS.md](AGENTS.md), defining roles, tools, memory model, playbooks, validation gates, and migration notes.  
- Declared full compatibility with the AGENTS.md open format: any agentic IDE/tool that reads AGENTS.md can orchestrate the Anti-Generic workflow (e.g., Claude Code, Cursor, Windsurf, VS Code extensions, CI bots).  
- Updated docs to reflect cross-tool support and MCP-first validation with Bright Data + Fetch fallback. See [README.md](README.md) and [docs/VALIDATION.md](docs/VALIDATION.md).  
- Backward compatible with the prior Claude Code subagents design. Filesystem memory paths and artifacts remain unchanged.  
- Security reminder retained: never commit secrets; see [docs/SECURITY.md](docs/SECURITY.md).
