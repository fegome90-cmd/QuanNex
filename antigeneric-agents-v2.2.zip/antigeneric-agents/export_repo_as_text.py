import os
import fnmatch
from collections import defaultdict, Counter
from datetime import datetime

try:
    import tiktoken
except ImportError:
    tiktoken = None

EXCLUDES = ['.git', '.DS_Store', 'node_modules', '__pycache__', '.venv', '.mypy_cache', '.pytest_cache']
GITIGNORE = '.gitignore'

def load_gitignore(root_dir):
    patterns = []
    gitignore_path = os.path.join(root_dir, GITIGNORE)
    if os.path.exists(gitignore_path):
        with open(gitignore_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    patterns.append(line)
    return patterns

def is_ignored(path, patterns):
    for pat in patterns:
        if fnmatch.fnmatch(path, pat):
            return True
    return False

def count_tokens(text, encoder=None):
    if encoder:
        return len(encoder.encode(text))
    return len(text.split())

def iter_files(root_dir, patterns):
    for dirpath, dirnames, filenames in os.walk(root_dir):
        dirnames[:] = [d for d in dirnames if d not in EXCLUDES]
        for filename in sorted(filenames):
            rel_path = os.path.relpath(os.path.join(dirpath, filename), root_dir)
            if filename in EXCLUDES or is_ignored(rel_path, patterns):
                continue
            yield rel_path

def build_dir_aggregates(file_infos):
    aggregates = defaultdict(lambda: {"files": 0, "tokens": 0, "bytes": 0})
    children = defaultdict(set)
    for info in file_infos:
        rel_path = info["path"]
        tokens = info["tokens"]
        size = info["bytes"]
        # accumulate for this file's directory and all ancestors
        dir_path = os.path.dirname(rel_path) or "."
        parts = [] if dir_path == "." else dir_path.split(os.sep)
        for i in range(len(parts) + 1):
            d = "." if i == 0 else os.sep.join(parts[:i])
            # Count file for all ancestor directories including root (represents total files under dir)
            aggregates[d]["files"] += 1
            aggregates[d]["tokens"] += tokens
            aggregates[d]["bytes"] += size
        # children map
        if dir_path != ".":
            parent = os.path.dirname(dir_path) or "."
            children[parent].add(dir_path)
        else:
            children["."].add(".")  # ensure root exists
    # ensure sets converted to sorted lists
    children = {k: sorted(v - {k}) for k, v in children.items()}
    return aggregates, children

def print_dir_tree(out, aggregates, children, current=".", prefix=""):
    # Print current directory line (skip printing for root at first call)
    if prefix == "":
        # root header printed separately by caller
        pass
    else:
        data = aggregates.get(current, {"files": 0, "tokens": 0, "bytes": 0})
        out.write(f"{prefix}{os.path.basename(current) or '.'}/ (files: {data['files']}, tokens: {data['tokens']}, bytes: {data['bytes']})\n")
    # children dirs
    dirs = sorted([d for d in children.get(current, []) if d != current])
    for idx, child in enumerate(dirs):
        is_last = idx == len(dirs) - 1
        branch = "└── " if is_last else "├── "
        next_prefix = (prefix.replace("└── ", "    ").replace("├── ", "│   ") if prefix else "") + branch
        print_dir_tree(out, aggregates, children, child, next_prefix)

def export_repo_as_text(root_dir, output_file):
    patterns = load_gitignore(root_dir)
    encoder = tiktoken.get_encoding('cl100k_base') if tiktoken else None
    tokenizer_name = 'cl100k_base' if encoder else 'words_approx'
    file_infos = []
    total_tokens = 0
    total_bytes = 0
    by_ext_tokens = Counter()
    by_ext_bytes = Counter()
    by_ext_files = Counter()
    with open(output_file, 'w', encoding='utf-8') as out:
        # Collect file infos first
        for rel_path in iter_files(root_dir, patterns):
            abs_path = os.path.join(root_dir, rel_path)
            try:
                with open(abs_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                tokens = count_tokens(content, encoder)
                lines = content.count('\n') + (1 if content and not content.endswith('\n') else 0)
                size = os.path.getsize(abs_path)
                file_infos.append({"path": rel_path, "tokens": tokens, "lines": lines, "bytes": size, "content": content})
                total_tokens += tokens
                total_bytes += size
                ext = os.path.splitext(rel_path)[1].lower() or "<no-ext>"
                by_ext_tokens[ext] += tokens
                by_ext_bytes[ext] += size
                by_ext_files[ext] += 1
            except Exception as e:
                print(f"[skip] {rel_path}: {e}")

        # Build aggregates and tree
        aggregates, children = build_dir_aggregates(file_infos)

        # Summary
        out.write('===== REPO SUMMARY =====\n')
        out.write(f"Generated: {datetime.now().isoformat()}\n")
        out.write(f"Tokenizer: {tokenizer_name}\n")
        out.write(f"Total files: {len(file_infos)}\n")
        out.write(f"Total tokens: {total_tokens}\n")
        out.write(f"Total bytes: {total_bytes}\n")

        # Extension breakdown
        out.write('\n===== SUMMARY BY EXTENSION =====\n')
        for ext in sorted(by_ext_files.keys()):
            out.write(f"{ext}: files={by_ext_files[ext]}, tokens={by_ext_tokens[ext]}, bytes={by_ext_bytes[ext]}\n")

        # Directory tree
        out.write('\n===== DIRECTORY TREE =====\n')
        root_data = aggregates.get('.', {"files": 0, "tokens": 0, "bytes": 0})
        out.write(f"./ (files: {root_data['files']}, tokens: {root_data['tokens']}, bytes: {root_data['bytes']})\n")
        print_dir_tree(out, aggregates, children, current='.', prefix='')

        # Files
        out.write('\n===== FILES =====\n')
        for info in sorted(file_infos, key=lambda x: x["path"]):
            out.write(f"\n===== FILE: {info['path']} =====\n")
            out.write(f"[TOKENS: {info['tokens']} | LINES: {info['lines']} | BYTES: {info['bytes']}]\n")
            out.write(info['content'])
            out.write('\n')

        # Detailed summary by file
        out.write(f"\n===== SUMMARY BY FILE =====\n")
        for info in sorted(file_infos, key=lambda x: x['tokens'], reverse=True):
            out.write(f"{info['path']} : {info['tokens']} tokens, {info['lines']} lines, {info['bytes']} bytes\n")

        # Top files
        out.write(f"\n===== TOP 20 BY TOKENS =====\n")
        for info in sorted(file_infos, key=lambda x: x['tokens'], reverse=True)[:20]:
            out.write(f"{info['path']} : {info['tokens']} tokens\n")
        out.write(f"\n===== TOP 20 BY BYTES =====\n")
        for info in sorted(file_infos, key=lambda x: x['bytes'], reverse=True)[:20]:
            out.write(f"{info['path']} : {info['bytes']} bytes\n")

if __name__ == "__main__":
    export_repo_as_text(os.path.dirname(os.path.abspath(__file__)), "repo_export.txt")
