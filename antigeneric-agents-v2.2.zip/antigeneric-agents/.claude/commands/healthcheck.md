# /healthcheck (Env & MCP readiness)

Run to verify environment readiness. The orchestrator can also trigger these checks autonomously on first run.

## Checks (non-destructive)
- Node & NPX present: `node -v`, `npx -v`
- Playwright MCP availability: `npx @playwright/mcp@latest --help` (won't start long-running server)
- Claude MCP registry (optional): `claude mcp list`
- Permissions sanity: confirm `.claude/settings.local.json` allow rules

## Expected Output
- Versions for node/npx
- Playwright MCP help output
- List of MCP servers (if Claude CLI installed)
- Any missing piece with a one-line fix suggestion

## Notes
- Visual validation step will request permission to start Playwright MCP if not running.
- Memory service is optional but recommended for long-lived context.
