# Persona 3: SEO Specialist Alex

## Demographics
- **Name**: Alex Thompson
- **Age**: 29
- **Location**: Denver, CO
- **Occupation**: Senior SEO Specialist at Digital Agency
- **Income**: $78,000/year
- **Education**: Bachelor's in Computer Science + SEO Certifications

## Background
Alex has been doing SEO for 7 years and prides themselves on staying ahead of algorithm updates. They're the go-to person for technical SEO at their agency. Recently, clients have been asking about AI optimization and LLM search, but Alex feels behind the curve.

## Goals
- Become the agency's AI search expert
- Offer cutting-edge services to justify premium rates
- Understand technical aspects of LLM optimization
- Stay ahead of competitors who are also learning
- Build personal brand as AI-era SEO thought leader

## Pain Points
- Limited information available about LLM search algorithms
- Current tools don't address AI search optimization
- Clients expect immediate expertise in new area
- Traditional SEO metrics don't apply to AI search
- Need to unlearn some old SEO habits

## Technology Usage
- Lives in Screaming Frog and Google Search Console
- Active in SEO Twitter and Reddit communities
- Listens to SEO podcasts during commute
- Experiments with new tools constantly
- Contributes to technical SEO blogs

## Decision Factors
- Technical depth: Needs sophisticated features
- Innovation: Must be ahead of mainstream tools
- Accuracy: Requires reliable, testable data
- Flexibility: Should allow custom configurations
- Community: Values expert user community

## Content Preferences
- Prefers technical documentation and API access
- Wants algorithm explanations and whitepapers
- Loves advanced features and customization
- Needs integration with existing SEO stack
- Values transparency in how tools work

## Quote
*"I've built my career on being ahead of SEO trends. AI search is the biggest shift yet, and I need tools that help me understand the technical side, not just give me surface-level recommendations."*

## Anti-Generic Messaging Approach
Appeal to their desire to be ahead of the curve. Position ALLMA as the tool for SEO professionals who want to master AI optimization, not just follow trends. Use technical language and emphasize innovation and thought leadership opportunities.