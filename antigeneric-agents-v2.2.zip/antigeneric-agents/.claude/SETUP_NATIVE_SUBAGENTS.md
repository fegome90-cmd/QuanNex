# Native Subagents Setup (Claude Code)

Esta guía permite ejecutar el sistema sin copy/paste, mediante lenguaje natural o un slash command.

## Quick Start

- Opción A (recomendada): selecciona el agente `design-orchestrator` y escribe:
  "Design anti-generic UI for <Proyecto> competing with <Competidor1, Competidor2>"
- Opción B: usa el Slash Command `/anti-iterate` con variables:
  ```
  /anti-iterate project:"AcmeApp" industry:"Fintech" audience:"SMBs US" goal:"Demo signups" locale:"en-US" competitors:"https://stripe.com, https://squareup.com"
  ```

El orquestador leerá `/.claude/memory/project_context.json`, preguntará faltantes en un solo paso, persistirá respuestas y orquestará subagentes.

## Readiness (healthcheck)

- Ejecuta `/.claude/commands/healthcheck.md` para verificar:
  - Node/NPX
  - Playwright MCP disponible (`npx @playwright/mcp@latest`)
  - Registro de MCPs (opcional): `claude mcp list`
  - Permisos en `/.claude/settings.local.json`

## MCPs

- Playwright MCP: `/.claude/commands/install-playwright-mcp.md`
- Memoria MCP (opcional, recomendado): `/.claude/commands/install-memory-mcp.md`

## Permisos sugeridos (`/.claude/settings.local.json`)

Asegúrate de permitir Bright Data y Fetch para el fallback del validador visual:
```json
{
  "permissions": {
    "allow": [
      "mcp__brave-search__brave_web_search",
      "mcp__fetch__fetch_markdown",
      "mcp__fetch__fetch_html",
      "mcp__brightdata-server__scrape_as_markdown",
      "mcp__brightdata-server__scraping_browser_navigate",
      "mcp__brightdata-server__scraping_browser_screenshot",
      "mcp__brightdata-server__scraping_browser_get_text",
      "mcp__brightdata-server__scraping_browser_get_html",
      "mcp__brightdata-server__scraping_browser_links",
      "mcp__brightdata-server__scraping_browser_wait_for",
      "mcp__brightdata-server__scraping_browser_scroll",
      "mcp__brightdata-server__scraping_browser_click",
      "mcp__brightdata-server__scraping_browser_type"
    ]
  }
}
```

## Flujo agéntico

1) `market-analyst` → research + `messaging_pivots.md`
2) `persona-forge` → personas con tono/locale/CTA triggers
3) `design-builder` → variantes A/B/C, `design_tokens/tokens.json`, `design_tokens/mapping.json`, `reports/integration.md`
4) `visual-validator` → Playwright MCP o fallback Bright Data + Fetch, `reports/validation.md`
5) `accessibility-guardian` → `reports/accessibility.md`
6) `performance-optimizer` → `reports/perf.md`
7) `resilience-sentinel` → `reports/resilience.md`
8) Snapshot → `/.claude/memory/iteration_history/`

## Políticas clave

- Locale por defecto: `en-US` (no traducir sin solicitud).
- Copy/CTA: no copiar competidores; generar 2–3 headlines/subheads y 3 CTAs por variante con micro-interacciones.
- Self-healing: exigir skeletons, reduced-motion, fallbacks y guardas SSR.
