# AGENTS.md — Anti-Generic UI/UX Agent System

This file guides AI coding agents to run the Premium Anti-Generic UI/UX multi-agent workflow in any IDE or runtime that supports AGENTS.md. It provides roles, tools, memory layout, playbooks, acceptance gates, permissions, and migration notes from Claude Code subagents.

## Scope
- Works standalone via this specification; no Claude Code required.
- Preserves and improves the original behavior described in [README.md](README.md) and subagent specs in [full-system/agents/](full-system/agents/).
- Outputs remain framework-agnostic with optional React/Vue/Svelte notes.

## Inputs (variables agents should collect)
- project: string
- industry: string
- audience: string
- goal: string
- constraints: string (optional)
- locale: string (default: en-US)
- competitors: comma-separated URLs (optional)

If any required field is missing, ask once concisely, then proceed and persist to memory.

## Directory layout (canonical)

```text
.claude/
├─ agents/                     # Optional, not required for AGENTS.md runtime
├─ commands/                   # Optional references
├─ memory/
│  ├─ iteration_history/
│  ├─ market_research/
│  ├─ personas/
│  ├─ design_tokens/
│  └─ project_context.json
variants/
reports/
design_tokens/
```

See also examples and templates in [full-system/commands/anti-iterate.md](full-system/commands/anti-iterate.md).

## Agent roles

- Orchestrator: design-orchestrator — coordinates phases, enforces policies, manages memory. See [design-orchestrator.md](full-system/agents/design-orchestrator.md)
- Research: market-analyst — competitive/differentiation analysis. See [market-analyst.md](full-system/agents/market-analyst.md)
- Personas: persona-forge — creates market-aware personas. See [persona-forge.md](full-system/agents/persona-forge.md)
- Builder: design-builder — generates A/B/C variants and tokens. See [design-builder.md](full-system/agents/design-builder.md)
- Visual QA: visual-validator — screenshots, diffs, uniqueness. See [visual-validator.md](full-system/agents/visual-validator.md)
- Accessibility: accessibility-guardian — WCAG without genericizing. See [accessibility-guardian.md](full-system/agents/accessibility-guardian.md)
- Performance: performance-optimizer — meets LCP/CLS/INP targets. See [performance-optimizer.md](full-system/agents/performance-optimizer.md)
- Resilience: resilience-sentinel — self-healing UI safeguards (documented in [README.md](README.md))

## Tools and MCP servers

Agents may use:
- Playwright MCP: `npx @playwright/mcp@latest` for visual validation.
- Bright Data MCP: scraping_browser_* and scrape_as_markdown for fallback screenshots and DOM capture.
- Fetch MCP: fetch_markdown, fetch_html as low-friction fallback.
- Brave Search MCP: brave_web_search for discovery.

Permissions allowlist (workspace-local) — [settings.local.json](README.md)

```json
{
  "permissions": {
    "allow": [
      "mcp__brave-search__brave_web_search",
      "mcp__fetch__fetch_markdown",
      "mcp__fetch__fetch_html",
      "mcp__brightdata-server__scrape_as_markdown",
      "mcp__brightdata-server__scraping_browser_navigate",
      "mcp__brightdata-server__scraping_browser_screenshot",
      "mcp__brightdata-server__scraping_browser_get_text",
      "mcp__brightdata-server__scraping_browser_get_html",
      "mcp__brightdata-server__scraping_browser_links",
      "mcp__brightdata-server__scraping_browser_wait_for",
      "mcp__brightdata-server__scraping_browser_scroll",
      "mcp__brightdata-server__scraping_browser_click",
      "mcp__brightdata-server__scraping_browser_type"
    ]
  }
}
```

Optional: Memory MCP. See [install-memory-mcp.md](full-system/commands/install-memory-mcp.md).

## Memory model

Canonical project context at [.claude/memory/project_context.json](full-system/memory/project_context.json). Agents must:
- Read locale and policies; never auto-translate unless requested.
- Deep-merge and preserve unknown fields.
- Write atomically (temp file -> fsync -> rename) and create timestamped backups.
- Maintain iteration snapshots under `.claude/memory/iteration_history/`.
- Retain for 90 days; purge expired artifacts.

Minimal schema (evolve forward-compatibly):

```json
{
  "schema_version": "1.0",
  "project_id": "string",
  "created": "YYYY-MM-DD",
  "last_updated": "ISO-8601",
  "locale": "en-US",
  "policies": {
    "copy_cta": {
      "force_iteration": true,
      "headlines_per_variant": 2,
      "ctas_per_variant": 3,
      "auto_translate": false,
      "do_not_copy_competitors": true
    },
    "resilience": {
      "require_skeletons": true,
      "reduced_motion": true,
      "network_fallbacks": true,
      "ssr_mismatch_guards": true
    }
  },
  "competitors": [],
  "market_insights": {},
  "design_decisions": [],
  "iterations": [],
  "design_tokens": {}
}
```

## Playbooks (routines)

### Playbook 1 — Iterate Premium (end-to-end)

1) Market research → market-analyst
   - Emit `.claude/memory/market_research/<project>.json`
   - Also write `differentiation_opportunities.md`, `anti_pattern_blacklist.yaml`, `messaging_pivots.md`
2) Personas → persona-forge
   - Write `.claude/memory/personas/<project>/` with 3–5 personas
3) Design variants → design-builder
   - Create `variants/<project>/{A,B,C}/` (html, css, optional js)
   - Emit `design_tokens/tokens.json` and `design_tokens/mapping.json`
   - For each variant: 2–3 headlines/subheads and 3 CTA variants with micro-interactions
4) Visual validation → visual-validator
   - Prefer Playwright MCP; fallback to Bright Data + Fetch
   - Produce `reports/visual_diff/` and `reports/validation.md`
5) Accessibility → accessibility-guardian
   - Produce `reports/accessibility.md` (WCAG 2.2 AA where feasible)
6) Performance → performance-optimizer
   - Produce `reports/perf.md` (targets below)
7) Resilience
   - Document in `reports/resilience.md` skeletons, reduced-motion, fallbacks, SSR guards
8) Snapshot
   - Save `.claude/memory/iteration_history/<timestamp>-<project>.json`

Gate conditions (auto-iterate until pass):
- Uniqueness ≥ 75
- Locale matches project_context.json
- ≥ 3 CTA variants per design variant
- No critical a11y contrast failures
- Perf targets: LCP < 2.5s, CLS < 0.1, INP < 200ms

### Playbook 2 — Iterate Persona (targeted)

Inputs: Component request + referenced persona files.
Behavior: For each persona, generate a single, self-contained HTML file with inline <style>, semantic markup, and an initial HTML comment explaining persona and strategy.
Output format: Write to `variants/<project>/persona_options/option_<persona>.html`.
Reference: [iterate-persona.md](full-system/commands/iterate-persona.md)

### Playbook 3 — Healthcheck

Verify environment readiness and permissions. Reference: [healthcheck.md](full-system/commands/healthcheck.md)

## Validation procedures

Preferred:
- Start Playwright MCP: `npx @playwright/mcp@latest`
- Capture sm/md/lg screenshots; verify hover/focus/scroll; compute uniqueness.

Fallback:
- Bright Data MCP: navigate, screenshot, get_text/get_html, wait_for, scroll, click, type
- Enrich with fetch_markdown/html

Checklist (enforced by visual-validator):
- Locale matches memory locale (no unsolicited translations)
- CTA presence and micro-interactions (≥3/variant)
- Responsiveness at sm=375, md=768, lg=1280
- Uniqueness score ≥ 75
- Basic a11y and contrast sanity

## Acceptance criteria

- Differentiated messaging and CTAs; never copy competitor content.
- Per-variant artifacts present; tokens and mapping emitted.
- Integration notes produced at `reports/integration.md`.
- Resilience report complete and actionable.

## Dev environment tips

- Node 18+; NPX available.
- Use `npx @playwright/mcp@latest` ad hoc, or register once (see [install-playwright-mcp.md](full-system/commands/install-playwright-mcp.md)).
- If using Claude CLI for MCP registration, see [install-memory-mcp.md](full-system/commands/install-memory-mcp.md).
- Keep this file and [docs/VALIDATION.md](docs/VALIDATION.md) open while running playbooks.

## Testing instructions

- Validate outputs exist:
  - `variants/<project>/{A,B,C}/index.html`
  - `design_tokens/tokens.json`, `design_tokens/mapping.json`
  - `reports/validation.md`, `reports/accessibility.md`, `reports/perf.md`, `reports/resilience.md`
- If HTML exists, run an HTML validator or open in a headless browser for smoke checks.
- Re-run Playbook 1 until gates pass.

## PR instructions

- Title format: [anti-generic-uiux] <Title>
- Ensure reports and tokens update coherently (no orphaned mappings).
- Do not commit secrets or scraping artifacts with PII; redact.
- If you modify memory schema, bump `schema_version` and add a migration note.

## Migration from Claude Code subagents

- Entry prompts from [anti-iterate.md](full-system/commands/anti-iterate.md) map directly to Playbook 1.
- Subagent markdown specs are normative; an AGENTS.md-aware agent should treat them as module contracts.
- Memory paths are unchanged. Filesystem persistence remains canonical.
- Visual validation primary tool is Playwright MCP; Bright Data + Fetch remain fallbacks.

## Security

- Never hardcode API keys. See [SECURITY.md](docs/SECURITY.md).
- Use least-privilege permissions allowlist shown above.
- Respect robots.txt and site terms during fallback scraping; throttle requests (≤1 req/sec, ≤3 concurrent by default).

## Appendix — Prompts for agents

Premium iteration (paste to orchestrator):

```text
Design anti-generic UI for "<ProjectName>" competing with <Competitor1>, <Competitor2>.
Industry: <Industry>. Audience/Geo: <Audience>. Primary goal: <Goal>. Constraints: <Constraints or none>.
Locale: en-US. Do not copy competitor content. Produce original, differentiated copy.
Run the full premium iteration: market-analyst → persona-forge → design-builder → visual-validator → accessibility-guardian → performance-optimizer → resilience-sentinel → snapshot.
Enforce copy/CTA policy: 2–3 headlines & subheads AND 3 CTA variants per design variant with micro-interaction specs.
Gate: If Uniqueness < 75 or Locale mismatch or CTAs < 3/variant, iterate and revalidate. Persist updates to .claude/memory/project_context.json.
```

Persona iteration (targeted):

See [iterate-persona.md](full-system/commands/iterate-persona.md) and emit persona_options per file.

## Versioning

- This file describes spec v1.0 for AGENTS.md runtime parity with the Claude Code–optimized design.
- Track changes in [CHANGELOG.md](CHANGELOG.md).

## Attribution

Based on the multi-agent system documented in [CLAUDE.md](CLAUDE.md) and product docs in [docs/PRODUCT_OVERVIEW.md](docs/PRODUCT_OVERVIEW.md).

## HITL (optional)

- Trigger criteria:
  - Uniqueness score between 70–80 after one full end-to-end iteration.
  - Conflicts in brand tone or potential legal risk flagged by `market-analyst`.
  - Accessibility blockers unresolved after one re-run.
- Action: Pause and request human approval before shipping. Resume automatically after approval or when thresholds are met.